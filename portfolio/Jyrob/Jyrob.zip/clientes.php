<?php
include_once "./head/header.php";
?>
<!-- menu -->
<nav class="navbar bg-n navbar-expand-lg h-5">
    <div class="container-fluid bg-n">
        <img src="./img/logoca.webp" alt="Logo de Jyrob" class="anch justify-content-center pa">
        <button class="navbar-toggler bg-b" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon text-white"></span>
            <br>
        </button>
        <div class="collapse navbar-collapse bg-n text-center" id="navbarTogglerDemo02" data-simplebar="" data-simplebar-auto-hide="true">
            <ul class="navbar-nav mx-auto bg-n mb-2 mb-lg-0 list-group list-group-vertical sidebar-menu do-nicescrol nav">
                <li class="nav-item">
                    <a class="nav-link link mx-2 fs-5 text-white mt-0 px-2" aria-current="page" href="./index.php" aria-label="Inicio">
                        Inicio
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link link-fancy-light mx-2 fs-5 text-white mt-0 px-2" href="./clientes.php" aria-label="Servicios Informáticos">
                        Clientes
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link mx-2 fs-5 text-white mt-0 px-2" href="./catalogos.php" aria-label="Diseño Gráfico">
                        Catálogos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link mx-2 fs-5 text-white mt-0 px-2" href="./sexshop.php" aria-label="Diseño Gráfico">
                        Sexshop
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="bg-n">
    <div class="w-100 overflow-hidden position-relative text-white" data-aos="fade">
        <div class="caja11" id="caja1">
            <span class="invisible">
                <br>
            </span>
            <div class="w-100 position-relative text-white d-flex align-items-center">
                <div class="container-fluid px-vw-5">
                    <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                        <div class="col-12 col-md-12 col-lg-12">
                            <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5 mx-0">
                                <div class="col-12 text-center">
                                    <span class="invisible">
                                        <br>
                                    </span>
                                    <p class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-up" data-aos-duration="1500">Comentarios y Agradecimientos</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="carouselIndicator" class="carousel slide pad" data-bs-interval="false">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="3" aria-label="Slide 4"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="4" aria-label="Slide 5"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="5" aria-label="Slide 6"></button>
                        </div>
                        <span class="invisible">
                            <br>
                        </span>
                        <div class="carousel-inner container px-5">
                            <div class="carousel-item active">
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="w-100 position-relative text-white d-flex align-items-center">
                                    <div class="container-fluid px-vw-5">
                                        <div class="row  d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                            <div class="col-12 col-md-6 col-lg-5">
                                                <img src="img/clientes/cl0.webp" alt="Imagen de Reparación de Software" class="img-fluid position-relative rounded-circle" data-aos="fade-right" data-aos-duration="1500">
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-12">
                                                <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                                    <div class="col-12 text-center mt-0">
                                                        <p class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-left" data-aos-duration="1500">Cliente Jyr</p>
                                                        <p class="position-relative text-center fst-italic fs-5" data-aos="fade-left" data-aos-duration="1500">
                                                            Complacida y agradecida con la tienda @Jyrob_yt por su cumplimiento y responsabilidad.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="w-100 position-relative text-white d-flex align-items-center">
                                    <div class="container-fluid px-vw-5">
                                        <div class="row  d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                            <div class="col-12 col-md-6 col-lg-5">
                                                <img src="img/clientes/cl0.webp" alt="Imagen de Reparación de Software" class="img-fluid position-relative rounded-circle" data-aos="fade-right" data-aos-duration="1500">
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-12">
                                                <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                                    <div class="col-12 text-center mt-0">
                                                        <p class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-left" data-aos-duration="1500">Cliente Jyr</p>
                                                        <p class="position-relative text-center fst-italic fs-5" data-aos="fade-left" data-aos-duration="1500">
                                                            Agradecida por la responsabilidad y cumplimiento de mi SmarTV justo a tiempo 🙏 @Jyrob_yt
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="w-100 position-relative text-white d-flex align-items-center">
                                    <div class="container-fluid px-vw-5">
                                        <div class="row  d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                            <div class="col-12 col-md-6 col-lg-5">
                                                <img src="img/clientes/cl0.webp" alt="Imagen de Reparación de Software" class="img-fluid position-relative rounded-circle" data-aos="fade-right" data-aos-duration="1500">
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-12">
                                                <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                                    <div class="col-12 text-center mt-0">
                                                        <p class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-left" data-aos-duration="1500">Cliente Jyr</p>
                                                        <p class="position-relative text-center fst-italic fs-5" data-aos="fade-left" data-aos-duration="1500">
                                                            Muchas gracias a ustedes por facilitar productos de buena calidad y por inspirar confianza
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="w-100 position-relative text-white d-flex align-items-center">
                                    <div class="container-fluid px-vw-5">
                                        <div class="row  d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                            <div class="col-12 col-md-6 col-lg-5">
                                                <img src="img/clientes/cl0.webp" alt="Imagen de Reparación de Software" class="img-fluid position-relative rounded-circle" data-aos="fade-right" data-aos-duration="1500">
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-12">
                                                <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                                    <div class="col-12 text-center mt-0">
                                                        <p class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-left" data-aos-duration="1500">Cliente Jyr</p>
                                                        <p class="position-relative text-center fst-italic fs-5" data-aos="fade-left" data-aos-duration="1500">
                                                            Excelentes productos y muy buena atención. Totalmente satisfecha!
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="w-100 position-relative text-white d-flex align-items-center">
                                    <div class="container-fluid px-vw-5">
                                        <div class="row  d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                            <div class="col-12 col-md-6 col-lg-5">
                                                <img src="img/clientes/cl0.webp" alt="Imagen de Reparación de Software" class="img-fluid position-relative rounded-circle" data-aos="fade-right" data-aos-duration="1500">
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-12">
                                                <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                                    <div class="col-12 text-center mt-0">
                                                        <p class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-left" data-aos-duration="1500">Cliente Jyr</p>
                                                        <p class="position-relative text-center fst-italic fs-5" data-aos="fade-left" data-aos-duration="1500">
                                                            Gracias por su atencion de parte de la cerrajeria cameco ☺️👍
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="w-100 position-relative text-white d-flex align-items-center">
                                    <div class="container-fluid px-vw-5">
                                        <div class="row  d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                            <div class="col-12 col-md-6 col-lg-5">
                                                <img src="img/clientes/cl0.webp" alt="Imagen de Reparación de Software" class="img-fluid position-relative rounded-circle" data-aos="fade-right" data-aos-duration="1500">
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-12">
                                                <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                                                    <div class="col-12 text-center mt-0">
                                                        <p class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-left" data-aos-duration="1500">Cliente Jyr</p>
                                                        <p class="position-relative text-center fst-italic fs-5" data-aos="fade-left" data-aos-duration="1500">
                                                            Hola buen dia, muy bueno el producto y a muy buen precio, muchas gracias
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button class="carousel-control-prev wi" type="button" data-bs-target="#carouselIndicator" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next wi" type="button" data-bs-target="#carouselIndicator" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                    <span class="invisible">
                        <br>
                        <br>
                    </span>
                </div>
            </div>
        </div>
        <div class="caja22" id="caja2">
            <span class="invisible">
                <br>
            </span>
            <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5 mx-0">
                        <div class="col-12 text-center">
                            <div class="col-12 text-center">
                                <span class="invisible">
                                    <br>
                                </span>
                                <p class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-up" data-aos-duration="1500">Clientes Felices</p>
                            </div>
                        </div>
                    </div>
                    <span class="invisible">
                        <br>
                        <br>
                    </span>
                </div>
            </div>
            <div class="w-100 position-relative text-white d-flex align-items-center">
                <div class="container-fluid px-vw-5">
                    <div class="row  d-flex align-items-center position-relative justify-content-center px-0 g-5">
                        <div class="col-12 col-md-6 col-lg-5">
                            <video src="./img/clientes/cl1.mp4" autoplay loop alt="Imagen de Reparación de Software" class="img-fluid position-relative rounded-5" data-aos="fade-right" data-aos-duration="1500"></video>
                        </div>
                        <div class="col-12 col-md-6 col-lg-5">
                            <img src="./img/clientes/cl4.webp" alt="Imagen de Productos Farmacéuticos" class="img-fluid position-relative rounded-5" data-aos="fade-left" data-aos-duration="1500">
                        </div>
                    </div>
                </div>
            </div>
            <span class="invisible">
                <br>
                <br>
            </span>
            <div class="w-100 position-relative text-white d-flex align-items-center">
                <div class="container-fluid px-vw-5">
                    <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                        <div class="col-12 col-md-6 col-lg-5">
                            <img src="./img/clientes/cl2.webp" alt="Imagen de Reparación de Software" class="img-fluid position-relative rounded-5" data-aos="fade-right" data-aos-duration="1500">
                        </div>
                        <div class="col-12 col-md-6 col-lg-5">
                            <img src="./img/clientes/cl3.webp" alt="Imagen de Productos Farmacéuticos" class="img-fluid position-relative rounded-5" data-aos="fade-left" data-aos-duration="1500">
                        </div>
                    </div>
                </div>
            </div>
            <span class="invisible">
                <br>
                <br>
            </span>
        </div>
    </div>
    <?php
    include_once "./head/footer.php";
    ?>