<?php
include_once "./head/header.php";
?>
<!-- menu -->
<nav class="navbar bg-n navbar-expand-lg h-5">
    <div class="container-fluid bg-n">
        <img src="./img/logoca.webp" alt="Logo de Jyrob" class="anch justify-content-center pa">
        <button class="navbar-toggler bg-b" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon text-white"></span>
            <br>
        </button>
        <div class="collapse navbar-collapse bg-n text-center" id="navbarTogglerDemo02" data-simplebar="" data-simplebar-auto-hide="true">
            <ul class="navbar-nav mx-auto bg-n mb-2 mb-lg-0 list-group list-group-vertical sidebar-menu do-nicescrol nav">
                <li class="nav-item">
                    <a class="nav-link link mx-2 fs-5 text-white mt-0 px-2" aria-current="page" href="./index.php" aria-label="Inicio">
                        Inicio
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link mx-2 fs-5 text-white mt-0 px-2" href="./clientes.php" aria-label="Servicios Informáticos">
                        Clientes
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link mx-2 fs-5 text-white mt-0 px-2" href="./catalogos.php" aria-label="Diseño Gráfico">
                        Catálogos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link link-fancy-light mx-2 fs-5 text-white mt-0 px-2" href="./sexshop.php" aria-label="Diseño Gráfico">
                        Sexshop
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="bg-n seccion">
    <div class="w-100 overflow-hidden position-relative text-white" data-aos="fade">
        <div class="d-flex align-items-center position-relative w-100 hw top-0 start-0 bg-i2">
        </div>
        <div class="caja11">
            <span class="invisible">
                <br>
            </span>
            <div class="w-100 position-relative text-white d-flex align-items-center">
                <div class="container-fluid px-vw-5">
                    <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5">
                        <div class="col-12 col-md-12 col-lg-12">
                            <div class="row d-flex align-items-center position-relative justify-content-center px-0 g-5 mx-0">
                                <div class="col-12 text-center">
                                    <span class="invisible">
                                        <br>
                                    </span>
                                    <h1 class="display-huge mt-3 mb-3 lh-1 title text-center title green" data-aos="fade-up" data-aos-duration="1500">Jyrob Sexshop</h1>
                                </div>
                            </div>
                            <span class="invisible">
                                <br>
                            </span>
                        </div>
                    </div>
                    <div id="carouselIndicator" class="carousel slide pad" data-bs-interval="false">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="3" aria-label="Slide 4"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="4" aria-label="Slide 5"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="5" aria-label="Slide 6"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="6" aria-label="Slide 7"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="7" aria-label="Slide 8"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="8" aria-label="Slide 9"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="9" aria-label="Slide 10"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="10" aria-label="Slide 11"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="11" aria-label="Slide 12"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="12" aria-label="Slide 13"></button>
                            <button type="button" data-bs-target="#carouselIndicator" data-bs-slide-to="13" aria-label="Slide 14"></button>
                        </div>
                        <div class="carousel-inner container px-5">
                            <div class="carousel-item active">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se1.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Kit de BDSM</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se2.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Anillo Vibrador Doble</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se3.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Vibrador Bluetooth</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se4.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Plug Anal con Cola</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se5.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Dildo Vibrador Flexible</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se6.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Kit de Bondash</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se7.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Satisfyer Penguin</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se8.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Vibradores Shibari Orchid Wireless 7 & Vibrador Tipo Micrófono</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se9.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Vibrador Conejito</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se10.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Vibrador Portátil con Control Remoto Inalámbrico</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se11.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Desensibilizante Masculino en Aerosol</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se12.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Lubricantes Húmedos</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se13.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Anillo Vibratorio Plusone</h2>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-12 col-md-6 col-lg-5 d-flex justify-content-center w-100">
                                    <img src="./img/sexshop/se14.webp" class="w-50 position-relative rounded-5 wi2" alt="Imágen de Jyrob Sexshop">
                                </div>
                                <span class="invisible">
                                    <br>
                                </span>
                                <div class="position-relative  d-flex justify-content-center w-100 flex-column text-center">
                                    <h2 class="h5">Anillo Vibratorio</h2>
                                </div>
                            </div>
                        </div>
                        <button class="carousel-control-prev wi" type="button" data-bs-target="#carouselIndicator" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next wi" type="button" data-bs-target="#carouselIndicator" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                    <span class="invisible">
                        <br>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include_once "./head/footer.php";
?>